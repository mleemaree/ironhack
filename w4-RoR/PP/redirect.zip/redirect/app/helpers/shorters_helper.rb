module ShortersHelper
end
