require 'test_helper'

class ShorterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
