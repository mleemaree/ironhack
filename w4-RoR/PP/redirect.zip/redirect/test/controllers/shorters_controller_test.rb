require 'test_helper'

class ShortersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
